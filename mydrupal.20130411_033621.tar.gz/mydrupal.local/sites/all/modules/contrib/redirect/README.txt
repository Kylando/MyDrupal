
This is the new module home for a unified redirection API (also replaces
path_redirect and globalredirect).
